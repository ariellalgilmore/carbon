/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { prefix } from '../../globals/settings.js';
import { html } from 'lit';
import { carbonElement } from '../../globals/decorators/carbon-element.js';
import CDSSelect from '../select/select.js';
import styles from './fluid-select.scss.js';
import { classMap } from 'lit/directives/class-map.js';
import { state } from 'lit/decorators.js';

/**
 * Copyright IBM Corp.2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Fluid text select.
 *
 * @element cds-custom-fluid-select
 */
let CDSFluidSelect = class CDSFluidSelect extends CDSSelect {
    constructor() {
        super(...arguments);
        this._hasFocus = false;
        this._handleToggleTipLabelClick = (event) => {
            const path = event.composedPath();
            const hasLabel = path.some((node) => node instanceof HTMLLabelElement);
            const hasToggleTip = path.some((node) => {
                var _a;
                return node instanceof HTMLElement &&
                    (((_a = node.matches) === null || _a === void 0 ? void 0 : _a.call(node, `${prefix}-toggletip`)) ||
                        node.classList.contains(`${prefix}--toggletip-button`));
            });
            if (hasLabel && hasToggleTip) {
                event.preventDefault();
            }
        };
        this._handleFocusIn = (event) => {
            var _a, _b;
            if ((_b = (_a = event.target) === null || _a === void 0 ? void 0 : _a.matches) === null || _b === void 0 ? void 0 : _b.call(_a, 'select')) {
                this._hasFocus = true;
            }
        };
        this._handleFocusOut = (event) => {
            var _a, _b;
            if ((_b = (_a = event.target) === null || _a === void 0 ? void 0 : _a.matches) === null || _b === void 0 ? void 0 : _b.call(_a, 'select')) {
                this._hasFocus = false;
            }
        };
    }
    connectedCallback() {
        this.setAttribute('isFluid', 'true');
        super.connectedCallback();
        this.addEventListener('click', this._handleToggleTipLabelClick, {
            capture: true,
        });
    }
    disconnectedCallback() {
        var _a;
        this.removeEventListener('click', this._handleToggleTipLabelClick, {
            capture: true,
        });
        (_a = super.disconnectedCallback) === null || _a === void 0 ? void 0 : _a.call(this);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('invalid') ||
            changedProperties.has('disabled') ||
            changedProperties.has('readonly') ||
            changedProperties.has('warn')) {
            this.requestUpdate();
        }
    }
    render() {
        const wrapperClasses = classMap({
            [`${prefix}--select`]: true,
            [`${prefix}--select--invalid`]: this.invalid,
            [`${prefix}--select--warning`]: this.warn && !this.invalid,
            [`${prefix}--select--disabled`]: this.disabled,
            [`${prefix}--select--readonly`]: this.readonly,
            [`${prefix}--select--fluid--focus`]: this._hasFocus,
        });
        return html `<div
      class="${wrapperClasses}"
      @focusin="${this._handleFocusIn}"
      @focusout="${this._handleFocusOut}">
      ${super.render()}
    </div>`;
    }
};
CDSFluidSelect.styles = [CDSSelect.styles, styles];
__decorate([
    state()
], CDSFluidSelect.prototype, "_hasFocus", void 0);
CDSFluidSelect = __decorate([
    carbonElement(`${prefix}-fluid-select`)
], CDSFluidSelect);
var CDSFluidSelect$1 = CDSFluidSelect;

export { CDSFluidSelect$1 as default };
//# sourceMappingURL=fluid-select.js.map
