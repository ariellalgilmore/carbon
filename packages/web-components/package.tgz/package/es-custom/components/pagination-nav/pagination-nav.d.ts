/**
 *
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
import '../icon-button';
import { PAGINATION_NAV_SIZE, PAGINATION_TOOLTIP_ALIGNMENT, PAGINATION_TOOLTIP_POSITION } from './defs';
/**
 * Translation IDs and default translations
 */
declare const translationIds: {
    readonly 'carbon.pagination-nav.next': "carbon.pagination-nav.next";
    readonly 'carbon.pagination-nav.previous': "carbon.pagination-nav.previous";
    readonly 'carbon.pagination-nav.item': "carbon.pagination-nav.item";
    readonly 'carbon.pagination-nav.active': "carbon.pagination-nav.active";
    readonly 'carbon.pagination-nav.of': "carbon.pagination-nav.of";
};
type TranslationKey = keyof typeof translationIds;
/**
 * Pagination Navigation.
 *
 * @element cds-custom-pagination-nav
 * @fires cds-custom-page-changed - The custom event fired when the the page has been changed.
 */
declare class CDSPaginationNav extends LitElement {
    /**
     * Internal state for items displayed on page
     */
    private itemsDisplayedOnPage;
    /**
     * Internal state for cuts
     */
    private cuts;
    /**
     * Internal state for previous page
     */
    private prevPage;
    /**
     * The number of items to be shown (minimum of 4 unless props.items < 4).
     */
    itemsShown: number;
    /**
     * Whether user should be able to loop through the items when reaching first / last.
     */
    loop: boolean;
    /**
     * The index of current page.
     */
    page: number;
    /**
     * The total number of items.
     */
    totalItems: number;
    /**
     * Specify the size of the PaginationNav.
     */
    size: PAGINATION_NAV_SIZE;
    /**
     * Specify the alignment of the tooltip for the icon-only next/prev buttons.
     * Can be one of: start, center, or end.
     */
    tooltipAlignment: PAGINATION_TOOLTIP_ALIGNMENT;
    /**
     * Specify the position of the tooltip for the icon-only next/prev buttons.
     * Can be one of: top, right, bottom, or left.
     */
    tooltipPosition: PAGINATION_TOOLTIP_POSITION;
    /**
     * If true, the '...' pagination overflow will not render page links between the first and last rendered buttons.
     * Set this to true if you are having performance problems with large data sets.
     */
    disableOverflow?: boolean;
    /**
     * Translates component strings using your i18n tool.
     */
    translateWithId: (messageId: TranslationKey) => string;
    private _calculateCuts;
    private _pageWouldBeHidden;
    /**
     * Sets the current page to a specified index.
     */
    private _setIndex;
    /**
     * Reduce current page by one, but no lower than 0.
     */
    private _decrementIndex;
    /**
     * Increase current page by one, but no higher than (this.totalItems - 1).
     */
    private _incrementIndex;
    /**
     * Renders a single pagination item & button.
     */
    private _renderPaginationItem;
    /**
     * Renders overflow items in a select list.
     *
     */
    private _renderPaginationOverflow;
    render(): import("lit-html").TemplateResult<1>;
    shouldUpdate(changedProperties: any): boolean;
    updated(changedProperties: any): void;
    static get eventChange(): string;
    static styles: any;
}
export default CDSPaginationNav;
