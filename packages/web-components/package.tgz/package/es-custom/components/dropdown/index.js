/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import './dropdown-skeleton.js';
import { registerGlobal } from '../../globals/register.js';
import CDSDropdown from './dropdown.js';
import CDSDropdownItem from './dropdown-item.js';

/**
 * Copyright IBM Corp. 2021, 2022
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// import './dropdown';
// import './dropdown-item';
registerGlobal(CDSDropdown, CDSDropdownItem);
//# sourceMappingURL=index.js.map
