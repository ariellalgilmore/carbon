/**
 * Copyright IBM Corp.2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSNumberInputSkeleton from '../number-input/number-input-skeleton';
/**
 * Fluid number input.
 *
 * @element cds-custom-fluid-number-input-skeleton
 */
declare class CDSFluidNumberInputSkeleton extends CDSNumberInputSkeleton {
    render(): import("lit-html").TemplateResult<1>;
    static styles: any[];
}
export default CDSFluidNumberInputSkeleton;
