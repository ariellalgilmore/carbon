/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { prefix } from '../../globals/settings.js';
import { html } from 'lit';
import { carbonElement } from '../../globals/decorators/carbon-element.js';
import styles from './fluid-number-input.scss.js';
import CDSNumberInputSkeleton from '../number-input/number-input-skeleton.js';

/**
 * Copyright IBM Corp.2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Fluid number input.
 *
 * @element cds-custom-fluid-number-input-skeleton
 */
let CDSFluidNumberInputSkeleton = class CDSFluidNumberInputSkeleton extends CDSNumberInputSkeleton {
    render() {
        return html ` ${super.render()} `;
    }
};
CDSFluidNumberInputSkeleton.styles = [CDSNumberInputSkeleton.styles, styles];
CDSFluidNumberInputSkeleton = __decorate([
    carbonElement(`${prefix}-fluid-number-input-skeleton`)
], CDSFluidNumberInputSkeleton);
var CDSFluidNumberInputSkeleton$1 = CDSFluidNumberInputSkeleton;

export { CDSFluidNumberInputSkeleton$1 as default };
//# sourceMappingURL=fluid-number-input-skeleton.js.map
