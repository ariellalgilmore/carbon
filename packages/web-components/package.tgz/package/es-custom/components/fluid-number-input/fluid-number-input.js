/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { prefix } from '../../globals/settings.js';
import { html } from 'lit';
import { carbonElement } from '../../globals/decorators/carbon-element.js';
import CDSNumberInput from '../number-input/number-input.js';
import styles from './fluid-number-input.scss.js';
import { classMap } from 'lit/directives/class-map.js';

/**
 * Copyright IBM Corp.2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Fluid number input.
 *
 * @element cds-custom-fluid-number-input
 */
let CDSFluidNumberInput = class CDSFluidNumberInput extends CDSNumberInput {
    connectedCallback() {
        this.setAttribute('isFluid', 'true');
        super.connectedCallback();
    }
    updated() {
        super.updated();
    }
    render() {
        const wrapperClasses = classMap({
            [`${prefix}--number-input--fluid`]: true,
            [`${prefix}--number-input--fluid--invalid`]: this.invalid,
            [`${prefix}--number-input--fluid--warning`]: this.warn && !this.invalid,
            [`${prefix}--number-input--fluid--disabled`]: this.disabled,
            [`${prefix}--number-input--fluid--readonly`]: this.readonly,
        });
        return html `<div class="${wrapperClasses}">${super.render()}</div>`;
    }
};
CDSFluidNumberInput.styles = [CDSNumberInput.styles, styles];
CDSFluidNumberInput = __decorate([
    carbonElement(`${prefix}-fluid-number-input`)
], CDSFluidNumberInput);
var CDSFluidNumberInput$1 = CDSFluidNumberInput;

export { CDSFluidNumberInput$1 as default };
//# sourceMappingURL=fluid-number-input.js.map
