/**
 * Copyright IBM Corp.2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSNumberInput from '../number-input/number-input';
/**
 * Fluid number input.
 *
 * @element cds-custom-fluid-number-input
 */
declare class CDSFluidNumberInput extends CDSNumberInput {
    connectedCallback(): void;
    updated(): void;
    render(): import("lit-html").TemplateResult<1>;
    static styles: any[];
}
export default CDSFluidNumberInput;
