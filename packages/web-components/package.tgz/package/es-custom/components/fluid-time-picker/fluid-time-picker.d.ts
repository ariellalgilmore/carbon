/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSTimePicker from '../time-picker/time-picker';
/**
 * Fluid Time Picker component.
 *
 * @element cds-custom-fluid-time-picker
 * @slot label-text - The label text.
 * @slot invalid-text - The invalid text.
 * @slot warning-text - The warning text.
 * @slot - slot for fluid time picker select components.
 */
declare class CDSFluidTimePicker extends CDSTimePicker {
    private _hoverTargets;
    private _handleSelectMouseEnter;
    private _handleSelectMouseLeave;
    private _getNormalizedProps;
    private _syncSelectState;
    private _setHoverState;
    private _syncHoverListeners;
    updated(changedProperties: any): void;
    protected _handleSlotChange(): void;
    disconnectedCallback(): void;
    render(): import("lit-html").TemplateResult<1>;
    static get selectorTimePickerSelect(): string;
    static styles: any[];
}
export default CDSFluidTimePicker;
