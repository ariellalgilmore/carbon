/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { LitElement, html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { property } from 'lit/decorators.js';
import { carbonElement } from '../../globals/decorators/carbon-element.js';
import { prefix } from '../../globals/settings.js';
import styles from './fluid-time-picker.scss.js';
import '../fluid-text-input/fluid-text-input-skeleton.js';
import '../fluid-select/fluid-select-skeleton.js';

/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Fluid time picker skeleton.
 *
 * @element cds-custom-fluid-time-picker-skeleton
 */
let CDSFluidTimePickerSkeleton = class CDSFluidTimePickerSkeleton extends LitElement {
    constructor() {
        super(...arguments);
        /**
         * Specify if there are only two TimePicker elements.
         */
        this.isOnlyTwo = false;
    }
    render() {
        const wrapperClasses = classMap({
            [`${prefix}--time-picker--fluid--skeleton`]: true,
            [`${prefix}--time-picker--equal-width`]: this.isOnlyTwo,
        });
        return html `
      <div class="${wrapperClasses}">
        <cds-custom-fluid-text-input-skeleton></cds-custom-fluid-text-input-skeleton>
        <cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>
        ${this.isOnlyTwo
            ? null
            : html `<cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>`}
      </div>
    `;
    }
};
CDSFluidTimePickerSkeleton.styles = styles;
__decorate([
    property({ type: Boolean, attribute: 'is-only-two', reflect: true })
], CDSFluidTimePickerSkeleton.prototype, "isOnlyTwo", void 0);
CDSFluidTimePickerSkeleton = __decorate([
    carbonElement(`${prefix}-fluid-time-picker-skeleton`)
], CDSFluidTimePickerSkeleton);
var CDSFluidTimePickerSkeleton$1 = CDSFluidTimePickerSkeleton;

export { CDSFluidTimePickerSkeleton$1 as default };
//# sourceMappingURL=fluid-time-picker-skeleton.js.map
