/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
import '../fluid-text-input/fluid-text-input-skeleton';
import '../fluid-select/fluid-select-skeleton';
/**
 * Fluid time picker skeleton.
 *
 * @element cds-custom-fluid-time-picker-skeleton
 */
declare class CDSFluidTimePickerSkeleton extends LitElement {
    /**
     * Specify if there are only two TimePicker elements.
     */
    isOnlyTwo: boolean;
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSFluidTimePickerSkeleton;
