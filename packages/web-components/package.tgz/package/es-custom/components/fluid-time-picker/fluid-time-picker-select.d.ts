/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSFluidSelect from '../fluid-select/fluid-select';
/**
 * Fluid time picker select.
 *
 * @element cds-custom-fluid-time-picker-select
 */
declare class CDSFluidTimePickerSelect extends CDSFluidSelect {
    /**
     * Optionally provide the default value of the select.
     */
    defaultValue: string;
    updated(changedProperties: any): void;
    static styles: any[];
}
export default CDSFluidTimePickerSelect;
