/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { property } from 'lit/decorators.js';
import { prefix } from '../../globals/settings.js';
import { carbonElement } from '../../globals/decorators/carbon-element.js';
import CDSFluidSelect from '../fluid-select/fluid-select.js';
import styles from './fluid-time-picker.scss.js';

/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Fluid time picker select.
 *
 * @element cds-custom-fluid-time-picker-select
 */
let CDSFluidTimePickerSelect = class CDSFluidTimePickerSelect extends CDSFluidSelect {
    constructor() {
        super(...arguments);
        /**
         * Optionally provide the default value of the select.
         */
        this.defaultValue = '';
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('defaultValue') &&
            this.defaultValue &&
            !this.value) {
            this.value = this.defaultValue;
        }
    }
};
CDSFluidTimePickerSelect.styles = [...CDSFluidSelect.styles, styles];
__decorate([
    property({ attribute: 'default-value' })
], CDSFluidTimePickerSelect.prototype, "defaultValue", void 0);
CDSFluidTimePickerSelect = __decorate([
    carbonElement(`${prefix}-fluid-time-picker-select`)
], CDSFluidTimePickerSelect);
var CDSFluidTimePickerSelect$1 = CDSFluidTimePickerSelect;

export { CDSFluidTimePickerSelect$1 as default };
//# sourceMappingURL=fluid-time-picker-select.js.map
