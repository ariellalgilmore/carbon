/**
 * Copyright IBM Corp. 2019, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
/**
 * Breadcrumb item.
 *
 * @element cds-custom-breadcrumb-item
 */
declare class CDSBreadcrumbItem extends LitElement {
    /**
     * Handles `slotchange` event.
     */
    private _handleSlotChange;
    connectedCallback(): void;
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSBreadcrumbItem;
