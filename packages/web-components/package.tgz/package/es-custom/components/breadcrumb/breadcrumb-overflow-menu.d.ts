/**
 * Copyright IBM Corp. 2019, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSOverflowMenu from '../overflow-menu/overflow-menu';
/**
 * Overflow menu in breadcrumb.
 *
 * @deprecated use `cds-custom-overflow-menu` instead with the `breadcrumb` property
 *
 * @element cds-custom-breadcrumb-overflow-menu
 */
declare class CDSBreadcrumbOverflowMenu extends CDSOverflowMenu {
    connectedCallback(): void;
    render(): import("lit-html").TemplateResult<1>;
}
export default CDSBreadcrumbOverflowMenu;
