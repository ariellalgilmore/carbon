/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { adoptStyles, html } from 'lit';
import { prefix } from '../../globals/settings.js';
import CDSOverflowMenu from '../overflow-menu/overflow-menu.js';
import OverflowMenuHorizontal16 from '@carbon/icons/es/overflow-menu--horizontal/16.js';
import { iconLoader } from '../../globals/internal/icon-loader.js';
import styles from '../overflow-menu/overflow-menu.scss.js';
import styles$1 from './breadcrumb.scss.js';
import { carbonElement } from '../../globals/decorators/carbon-element.js';

/**
 * Copyright IBM Corp. 2019, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Overflow menu in breadcrumb.
 *
 * @deprecated use `cds-custom-overflow-menu` instead with the `breadcrumb` property
 *
 * @element cds-custom-breadcrumb-overflow-menu
 */
let CDSBreadcrumbOverflowMenu = class CDSBreadcrumbOverflowMenu extends CDSOverflowMenu {
    connectedCallback() {
        super.connectedCallback();
        adoptStyles(this.renderRoot, [styles, styles$1]);
    }
    render() {
        return html `
      <slot name="icon">
        ${iconLoader(OverflowMenuHorizontal16, {
            class: `${prefix}--overflow-menu__icon`,
            slot: 'icon',
        })}
      </slot>
    `;
    }
};
CDSBreadcrumbOverflowMenu = __decorate([
    carbonElement(`${prefix}-breadcrumb-overflow-menu`)
], CDSBreadcrumbOverflowMenu);
var CDSBreadcrumbOverflowMenu$1 = CDSBreadcrumbOverflowMenu;

export { CDSBreadcrumbOverflowMenu$1 as default };
//# sourceMappingURL=breadcrumb-overflow-menu.js.map
