/**
 * Copyright IBM Corp. 2020, 2022, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Spinner types.
 */
export declare enum LOADING_TYPE {
    /**
     * Regular spinner.
     */
    REGULAR = "regular",
    /**
     * Small spinner.
     */
    SMALL = "small"
}
