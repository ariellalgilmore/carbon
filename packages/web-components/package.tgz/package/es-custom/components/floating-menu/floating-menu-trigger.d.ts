/**
 * Copyright IBM Corp. 2019, 2022, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * The interface of floating menus containing the trigger button.
 */
interface CDSFloatingMenuTrigger extends HTMLElement {
    /**
     * `true` if the menu should be open.
     */
    open: boolean;
    /**
     * The position of the trigger button.
     */
    triggerPosition: ClientRect;
}
export default CDSFloatingMenuTrigger;
