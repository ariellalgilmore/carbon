/**
 * Copyright IBM Corp. 2019, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
/**
 * Modal body.
 *
 * @element cds-custom-modal-body
 */
declare class CDSModalBody extends LitElement {
    private userDefinedTabindex;
    private _resizeObserver?;
    connectedCallback(): void;
    disconnectedCallback(): void;
    checkScroll(): void;
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSModalBody;
