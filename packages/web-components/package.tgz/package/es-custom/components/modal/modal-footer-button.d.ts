/**
 * Copyright IBM Corp. 2021, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSButton from '../button/button';
/**
 * Modal footer button.
 *
 * @element cds-custom-modal-footer-button
 */
declare class CDSModalFooterButton extends CDSButton {
    static styles: any[];
}
export default CDSModalFooterButton;
