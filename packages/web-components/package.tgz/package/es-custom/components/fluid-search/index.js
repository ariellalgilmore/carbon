/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import './fluid-search.js';
import './fluid-search-skeleton.js';
//# sourceMappingURL=index.js.map
