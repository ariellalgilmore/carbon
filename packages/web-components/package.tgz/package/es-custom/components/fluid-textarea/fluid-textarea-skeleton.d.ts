/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import CDSTextareaSkeleton from '../textarea/textarea-skeleton';
/**
 * Fluid text area skeleton.
 *
 * @element cds-custom-fluid-textarea-skeleton
 */
declare class CDSFluidTextareaSkeleton extends CDSTextareaSkeleton {
    render(): import("lit-html").TemplateResult<1>;
    static styles: any[];
}
export default CDSFluidTextareaSkeleton;
