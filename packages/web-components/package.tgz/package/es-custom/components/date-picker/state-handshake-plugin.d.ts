/**
 * Copyright IBM Corp. 2019, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { Plugin } from 'flatpickr/dist/types/options';
import CDSDatePicker from './date-picker';
/**
 * @param datePicker Plugin configuration.
 * @returns A Flatpickr plugin to handshake states with `<cds-custom-date-picker>`.
 */
declare const _default: (datePicker: CDSDatePicker) => Plugin;
export default _default;
