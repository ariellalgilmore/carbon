/**
 * Copyright IBM Corp. 2019, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
/**
 * Badge Indicator.
 *
 * @element cds-custom-badge-indicator
 */
declare class CDSBadgeIndicator extends LitElement {
    /**
     * Count of badge indicator
     */
    count: any;
    /**
     * The shadow slot the badge-indicator should be in.
     */
    slot: string;
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSBadgeIndicator;
