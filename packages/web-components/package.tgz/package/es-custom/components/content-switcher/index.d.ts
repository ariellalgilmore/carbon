/**
 * Copyright IBM Corp. 2021, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import '../tooltip/tooltip';
import '../tooltip/tooltip-content';
import './content-switcher';
import './content-switcher-item';
