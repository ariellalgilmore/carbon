/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { LitElement, html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { prefix } from '../../globals/settings.js';
import styles from './contained-list.scss.js';
import { carbonElement } from '../../globals/decorators/carbon-element.js';

/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Contained list.
 *
 * @element cds-custom-contained-list
 * @slot - The list items (cds-custom-contained-list-item elements)
 * @slot action - The action slot for interactive elements in header
 * @slot label - The label text
 */
let CDSContainedList = class CDSContainedList extends LitElement {
    constructor() {
        super(...arguments);
        /**
         * Specify whether the dividing lines in between list items should be inset.
         */
        this.isInset = false;
        /**
         * The kind of ContainedList you want to display
         */
        this.kind = 'on-page';
        /**
         * A label describing the contained list.
         */
        this.label = '';
    }
    render() {
        const { isInset, kind, label, size } = this;
        const classes = classMap({
            [`${prefix}--contained-list`]: true,
            [`${prefix}--contained-list--${kind}`]: true,
            [`${prefix}--contained-list--inset-rulers`]: isInset,
            [`${prefix}--layout--size-${size}`]: !!size,
        });
        const hasLabelSlot = this.querySelector('[slot="label"]') !== null;
        return html `
      <div class="${classes}">
        ${label || hasLabelSlot
            ? html `
              <div class="${prefix}--contained-list__header">
                <div class="${prefix}--contained-list__label">
                  ${hasLabelSlot ? html `<slot name="label"></slot>` : label}
                </div>
                <div class="${prefix}--contained-list__action">
                  <slot name="action"></slot>
                </div>
              </div>
            `
            : ''}
        <ul role="list">
          <slot></slot>
        </ul>
      </div>
    `;
    }
};
CDSContainedList.styles = styles;
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'is-inset' })
], CDSContainedList.prototype, "isInset", void 0);
__decorate([
    property({ reflect: true })
], CDSContainedList.prototype, "kind", void 0);
__decorate([
    property({ reflect: true })
], CDSContainedList.prototype, "label", void 0);
__decorate([
    property({ reflect: true })
], CDSContainedList.prototype, "size", void 0);
CDSContainedList = __decorate([
    carbonElement(`${prefix}-contained-list`)
], CDSContainedList);
var CDSContainedList$1 = CDSContainedList;

export { CDSContainedList$1 as default };
//# sourceMappingURL=contained-list.js.map
