/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
/**
 * Contained list item.
 *
 * @element cds-custom-contained-list-item
 * @slot - The content of the list item
 * @slot icon - The icon slot for rendering an icon
 * @slot action - The action slot for interactive elements
 * @fires cds-custom-contained-list-item-click - Fires when clickable item is clicked
 */
declare class CDSContainedListItem extends LitElement {
    /**
     * Whether this item is clickable
     */
    clickable: boolean;
    /**
     * Whether this item is disabled.
     */
    disabled: boolean;
    /**
     * Handles slot change for icon
     */
    private _handleIconSlotChange;
    private _hasIcon;
    /**
     * Handles click event
     */
    private _handleClick;
    connectedCallback(): void;
    render(): import("lit-html").TemplateResult<1>;
    /**
     * The name of the custom event fired when a clickable item is clicked
     */
    static get eventClick(): string;
    static styles: any;
}
export default CDSContainedListItem;
