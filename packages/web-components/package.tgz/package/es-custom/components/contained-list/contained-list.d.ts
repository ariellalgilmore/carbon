/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
export type Variants = 'on-page' | 'disclosed';
/**
 * Contained list.
 *
 * @element cds-custom-contained-list
 * @slot - The list items (cds-custom-contained-list-item elements)
 * @slot action - The action slot for interactive elements in header
 * @slot label - The label text
 */
declare class CDSContainedList extends LitElement {
    /**
     * Specify whether the dividing lines in between list items should be inset.
     */
    isInset: boolean;
    /**
     * The kind of ContainedList you want to display
     */
    kind: Variants;
    /**
     * A label describing the contained list.
     */
    label: string;
    /**
     * Specify the size of the contained list.
     */
    size?: 'sm' | 'md' | 'lg' | 'xl';
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSContainedList;
