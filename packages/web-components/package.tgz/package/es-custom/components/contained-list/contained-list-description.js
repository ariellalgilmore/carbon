/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { LitElement, html } from 'lit';
import { prefix } from '../../globals/settings.js';
import styles from './contained-list.scss.js';
import { carbonElement } from '../../globals/decorators/carbon-element.js';

/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Contained list description text.
 *
 * @element cds-custom-contained-list-description
 * @slot - The description text content
 */
let CDSContainedListDescription = class CDSContainedListDescription extends LitElement {
    render() {
        return html `<slot></slot>`;
    }
};
CDSContainedListDescription.styles = styles;
CDSContainedListDescription = __decorate([
    carbonElement(`${prefix}-contained-list-description`)
], CDSContainedListDescription);
var CDSContainedListDescription$1 = CDSContainedListDescription;

export { CDSContainedListDescription$1 as default };
//# sourceMappingURL=contained-list-description.js.map
