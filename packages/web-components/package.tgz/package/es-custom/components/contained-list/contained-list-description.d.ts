/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { LitElement } from 'lit';
/**
 * Contained list description text.
 *
 * @element cds-custom-contained-list-description
 * @slot - The description text content
 */
declare class CDSContainedListDescription extends LitElement {
    render(): import("lit-html").TemplateResult<1>;
    static styles: any;
}
export default CDSContainedListDescription;
