import { ACCORDION_SIZE, ACCORDION_ALIGNMENT } from './defs';
import { ScopedLitElement } from '../../globals/base/scoped-lit-element';
import CDSAccordionItem from './accordion-item';
export { ACCORDION_SIZE, ACCORDION_ALIGNMENT };
/**
 * Accordion container.
 *
 * @element cds-custom-accordion
 */
declare class CDSAccordion extends ScopedLitElement {
    /**
     * Scoped element registry — declares which child components this component
     * uses in its template or queries. Evaluated lazily as a getter so the
     * prefix is resolved at element upgrade time, after any `setPrefix()` call.
     */
    static get scopedElements(): {
        [x: string]: typeof CDSAccordionItem;
    };
    /**
     * Accordion size should be sm, md, lg.
     */
    size: ACCORDION_SIZE;
    /**
     * Specify the alignment of the accordion heading title and chevron.
     */
    alignment: ACCORDION_ALIGNMENT;
    /**
     * Specify whether Accordion text should be flush, default is false,
     * does not work with align="start".
     */
    isFlush: boolean;
    /**
     * Disable all accordion items inside this accordion.
     */
    disabled: boolean;
    connectedCallback(): void;
    updated(changedProperties: Map<string, unknown>): void;
    render(): import("lit-html").TemplateResult<1>;
    /**
     * Selector for querying accordion item descendants.
     * Resolved at call time so it respects any `setPrefix()` call.
     */
    static get selectorAccordionItems(): string;
    static styles: any;
}
export default CDSAccordion;
