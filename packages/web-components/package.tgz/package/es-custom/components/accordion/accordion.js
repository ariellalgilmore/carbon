/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { getPrefix } from '../../globals/settings.js';
import { forEach } from '../../globals/internal/collection-helpers.js';
import { ACCORDION_SIZE, ACCORDION_ALIGNMENT } from './defs.js';
import { ScopedLitElement } from '../../globals/base/scoped-lit-element.js';
import { TAG_NAME, BASE_NAME } from '../../globals/decorators/carbon-element.js';
import CDSAccordionItem from './accordion-item.js';
import styles from './accordion.scss.js';

var _a;
/**
 * Accordion container.
 *
 * @element cds-custom-accordion
 */
class CDSAccordion extends ScopedLitElement {
    constructor() {
        super(...arguments);
        /**
         * Accordion size should be sm, md, lg.
         */
        this.size = ACCORDION_SIZE.MEDIUM;
        /**
         * Specify the alignment of the accordion heading title and chevron.
         */
        this.alignment = ACCORDION_ALIGNMENT.END;
        /**
         * Specify whether Accordion text should be flush, default is false,
         * does not work with align="start".
         */
        this.isFlush = false;
        /**
         * Disable all accordion items inside this accordion.
         */
        this.disabled = false;
    }
    /**
     * Scoped element registry — declares which child components this component
     * uses in its template or queries. Evaluated lazily as a getter so the
     * prefix is resolved at element upgrade time, after any `setPrefix()` call.
     */
    static get scopedElements() {
        return {
            [`${getPrefix()}-accordion-item`]: CDSAccordionItem,
        };
    }
    connectedCallback() {
        if (!this.hasAttribute('role')) {
            this.setAttribute('role', 'list');
        }
        super.connectedCallback();
    }
    updated(changedProperties) {
        if (changedProperties.has('size')) {
            forEach(this.querySelectorAll(CDSAccordion.selectorAccordionItems), (elem) => {
                elem.setAttribute('size', this.size);
            });
        }
        if (changedProperties.has('alignment')) {
            forEach(this.querySelectorAll(CDSAccordion.selectorAccordionItems), (elem) => {
                elem.setAttribute('alignment', this.alignment);
            });
        }
        if (changedProperties.has('isFlush') ||
            changedProperties.has('alignment')) {
            forEach(this.querySelectorAll(CDSAccordion.selectorAccordionItems), (elem) => {
                if (this.isFlush && this.alignment !== 'start') {
                    elem.setAttribute('isFlush', '');
                }
                else {
                    elem.removeAttribute('isFlush');
                }
            });
        }
        if (changedProperties.has('disabled')) {
            forEach(this.querySelectorAll(CDSAccordion.selectorAccordionItems), (elem) => {
                if (this.disabled) {
                    elem.setAttribute('disabled', '');
                }
                else {
                    elem.removeAttribute('disabled');
                }
            });
        }
        const items = Array.from(this.querySelectorAll(CDSAccordion.selectorAccordionItems));
        items.forEach((item) => item.removeAttribute('data-last-item'));
        const lastVisible = items
            .reverse()
            .find((item) => !item.hidden);
        lastVisible === null || lastVisible === void 0 ? void 0 : lastVisible.setAttribute('data-last-item', '');
    }
    render() {
        return html `<slot></slot>`;
    }
    /**
     * Selector for querying accordion item descendants.
     * Resolved at call time so it respects any `setPrefix()` call.
     */
    static get selectorAccordionItems() {
        return `${getPrefix()}-${CDSAccordionItem[BASE_NAME]}`;
    }
}
_a = BASE_NAME;
CDSAccordion[_a] = 'accordion';
CDSAccordion.styles = styles;
__decorate([
    property({ reflect: true })
], CDSAccordion.prototype, "size", void 0);
__decorate([
    property({ reflect: true })
], CDSAccordion.prototype, "alignment", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CDSAccordion.prototype, "isFlush", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CDSAccordion.prototype, "disabled", void 0);
Object.defineProperty(CDSAccordion, TAG_NAME, {
    get: () => `${getPrefix()}-${CDSAccordion[BASE_NAME]}`,
    configurable: true,
});

export { ACCORDION_ALIGNMENT, ACCORDION_SIZE, CDSAccordion as default };
//# sourceMappingURL=accordion.js.map
