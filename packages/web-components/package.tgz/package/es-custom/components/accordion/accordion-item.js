/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { __decorate } from 'tslib';
import { classMap } from 'lit/directives/class-map.js';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { getPrefix } from '../../globals/settings.js';
import ChevronRight16 from '@carbon/icons/es/chevron--right/16.js';
import { iconLoader } from '../../globals/internal/icon-loader.js';
import FocusMixin from '../../globals/mixins/focus.js';
import { ScopedLitElement } from '../../globals/base/scoped-lit-element.js';
import { TAG_NAME, BASE_NAME } from '../../globals/decorators/carbon-element.js';
import { ACCORDION_ITEM_BREAKPOINT } from './defs.js';
import styles from './accordion.scss.js';

/**
 * Copyright IBM Corp. 2019, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _a;
/**
 * Observes resize of the given element with the given resize observer.
 *
 * @param observer The resize observer.
 * @param elem The element to observe the resize.
 */
const observeResize = (observer, elem) => {
    if (!elem) {
        return null;
    }
    observer.observe(elem);
    return {
        release() {
            observer.unobserve(elem);
            return null;
        },
    };
};
/**
 * Accordion item.
 *
 * @element cds-custom-accordion-item
 * @fires cds-custom-accordion-item-beingtoggled
 *   The custom event fired before this accordion item is being toggled upon a user gesture.
 *   Cancellation of this event stops the user-initiated action of toggling this accordion item.
 * @fires cds-custom-accordion-item-toggled - The custom event fired after this accordion item is toggled upon a user gesture.
 * @csspart title The title.
 * @csspart content The content.
 */
class CDSAccordionItem extends FocusMixin(ScopedLitElement) {
    constructor() {
        super(...arguments);
        /**
         * The handle for observing resize of the parent element of this element.
         */
        this._hObserveResize = null;
        /**
         * Handler for the `keydown` event on the expando button.
         */
        this._handleKeydownExpando = ({ key }) => {
            if (this.open && (key === 'Esc' || key === 'Escape')) {
                this._handleUserInitiatedToggle(false);
            }
        };
        /**
         * The `ResizeObserver` instance for observing element resizes for re-positioning floating menu position.
         */
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment -- https://github.com/carbon-design-system/carbon/issues/20452
        // @ts-ignore
        this._resizeObserver = new ResizeObserver((records) => {
            const { width } = records[records.length - 1].contentRect;
            const { _sizesBreakpoints: sizesBreakpoints } = this
                .constructor;
            this._currentBreakpoint = Object.keys(sizesBreakpoints)
                .sort((lhs, rhs) => sizesBreakpoints[rhs] - sizesBreakpoints[lhs])
                .find((size) => width >= sizesBreakpoints[size]);
            this.requestUpdate();
        });
        /**
         * `true` if the accordion item should be disabled.
         */
        this.disabled = false;
        /**
         * `true` if the accordion item should be open.
         */
        this.open = false;
        /**
         * The title text.
         */
        this.title = '';
    }
    /**
     * Handles user-initiated toggle request of this accordion item.
     *
     * @param open The new open state.
     */
    _handleUserInitiatedToggle(open = !this.open) {
        const init = {
            bubbles: true,
            cancelable: true,
            composed: true,
            detail: {
                open,
            },
        };
        if (this.dispatchEvent(new CustomEvent(this.constructor.eventBeforeToggle, init))) {
            const { selectorAccordionContent } = this
                .constructor;
            if (!this.open) {
                this.setAttribute('expanding', '');
            }
            else {
                this.setAttribute('collapsing', '');
            }
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion -- https://github.com/carbon-design-system/carbon/issues/20452
            this.shadowRoot.querySelector(selectorAccordionContent).addEventListener('animationend', () => {
                this.removeAttribute('expanding');
                this.removeAttribute('collapsing');
            });
            this.open = open;
            this.dispatchEvent(new CustomEvent(this.constructor.eventToggle, init));
        }
    }
    /**
     * Handler for the `click` event on the expando button.
     */
    _handleClickExpando() {
        this._handleUserInitiatedToggle();
    }
    connectedCallback() {
        if (!this.hasAttribute('role')) {
            this.setAttribute('role', 'listitem');
        }
        super.connectedCallback();
        if (this._hObserveResize) {
            this._hObserveResize = this._hObserveResize.release();
        }
        this._hObserveResize = observeResize(this._resizeObserver, this);
    }
    disconnectedCallback() {
        if (this._hObserveResize) {
            this._hObserveResize = this._hObserveResize.release();
        }
    }
    render() {
        const { disabled, title, open, _currentBreakpoint: currentBreakpoint, _handleClickExpando: handleClickExpando, _handleKeydownExpando: handleKeydownExpando, } = this;
        const { _classesBreakpoints: classesBreakpoints } = this
            .constructor;
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion -- https://github.com/carbon-design-system/carbon/issues/20452
        const { [currentBreakpoint]: classBreakpoint } = classesBreakpoints;
        const p = getPrefix();
        const contentClasses = classMap({
            [classBreakpoint]: classBreakpoint,
            [`${p}--accordion__content`]: true,
        });
        return html `
      <button
        ?disabled="${disabled}"
        type="button"
        part="expando"
        class="${p}--accordion__heading"
        aria-controls="content"
        aria-expanded="${open}"
        @click="${handleClickExpando}"
        @keydown="${handleKeydownExpando}">
        ${iconLoader(ChevronRight16, {
            part: 'expando-icon',
            class: `${p}--accordion__arrow`,
        })}
        <div part="title" class="${p}--accordion__title">
          <slot name="title">${title}</slot>
        </div>
      </button>
      <div class="${p}--accordion__wrapper" part="wrapper">
        <div id="content" part="content" class="${contentClasses}">
          <slot></slot>
        </div>
      </div>
    `;
    }
    /**
     * The CSS classes for breakpoints.
     * Evaluated as a getter so the prefix is resolved at call time.
     *
     * @private
     */
    static get _classesBreakpoints() {
        const p = getPrefix();
        return {
            [ACCORDION_ITEM_BREAKPOINT.SMALL]: `${p}-ce--accordion__content--${ACCORDION_ITEM_BREAKPOINT.SMALL}`,
            [ACCORDION_ITEM_BREAKPOINT.MEDIUM]: `${p}-ce--accordion__content--${ACCORDION_ITEM_BREAKPOINT.MEDIUM}`,
        };
    }
    /**
     * The breakpoints.
     *
     * @private
     */
    static get _sizesBreakpoints() {
        return {
            [ACCORDION_ITEM_BREAKPOINT.SMALL]: 480,
            [ACCORDION_ITEM_BREAKPOINT.MEDIUM]: 640,
        };
    }
    /**
     * The name of the custom event fired before this accordion item is being toggled upon a user gesture.
     * Cancellation of this event stops the user-initiated action of toggling this accordion item.
     */
    static get eventBeforeToggle() {
        return `${getPrefix()}-accordion-item-beingtoggled`;
    }
    /**
     * The name of the custom event fired after this accordion item is toggled upon a user gesture.
     */
    static get eventToggle() {
        return `${getPrefix()}-accordion-item-toggled`;
    }
    /**
     * Selector for the accordion content element within the shadow root.
     */
    static get selectorAccordionContent() {
        return `.${getPrefix()}--accordion__content`;
    }
}
_a = BASE_NAME;
CDSAccordionItem[_a] = 'accordion-item';
CDSAccordionItem.styles = styles;
__decorate([
    property({ type: Boolean, reflect: true })
], CDSAccordionItem.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CDSAccordionItem.prototype, "open", void 0);
__decorate([
    property({ attribute: 'title' })
], CDSAccordionItem.prototype, "title", void 0);
Object.defineProperty(CDSAccordionItem, TAG_NAME, {
    get: () => `${getPrefix()}-${CDSAccordionItem[BASE_NAME]}`,
    configurable: true,
});

export { ACCORDION_ITEM_BREAKPOINT, CDSAccordionItem as default };
//# sourceMappingURL=accordion-item.js.map
