/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { registerGlobal } from '../../globals/register.js';
import CDSAccordion from './accordion.js';
import CDSAccordionItem from './accordion-item.js';
import CDSAccordionItemSkeleton from './accordion-item-skeleton.js';
import CDSAccordionSkeleton from './accordion-skeleton.js';

/**
 * Copyright IBM Corp. 2021, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
registerGlobal(CDSAccordion, CDSAccordionItem, CDSAccordionItemSkeleton, CDSAccordionSkeleton);

export { CDSAccordion, CDSAccordionItem, CDSAccordionItemSkeleton, CDSAccordionSkeleton };
//# sourceMappingURL=index.js.map
